import './bootstrap.mjs';

console.log("App loaded!");
